import crossbar

crossbar.run(["version"])
