-----------------------------
### fconboot04
NOEXISTS


-----------------------------
### fconboot03
Time : White 0600, Rainb 0400
Dist : fcondist03
ARCH : arm
Summ : Device tree appended to kernel.


-----------------------------
### fconboot02
Time : White 0800, Rainb 1200
Dist : fcondist02
ARCH : arm
Summ : Not so much customization.


-----------------------------
### fconboot01
Time : White 0600, Rainb 0400
Dist : NONE
ARCH : arm64
Summ : There is no file system for this. Just used for some debugging.
