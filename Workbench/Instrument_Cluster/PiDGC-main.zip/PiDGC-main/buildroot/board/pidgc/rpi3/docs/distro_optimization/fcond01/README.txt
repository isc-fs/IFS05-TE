----------------------- make kernel-xconfig
### Networking disabled
Disabled;
CONFIG_NET

### Sound disabled
Disabled;
CONFIG_SOUND

### File systems optimized
Summary;
Especially Ext4, journal etc.

### Time measurements
Kernel to Userspace : Not meausered
Userspace to App    : Not measured
Total boot time     : 3.10sec

### Total size
29.0 MB
