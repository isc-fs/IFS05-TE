#!/bin/sh

# This is tested on Linux 4.14.29

cp logo_linux_clut224.ppm ../../../../output/build/linux-*/drivers/video/logo/logo_linux_clut224.ppm
echo ">>> Boot image is successfully changed."
