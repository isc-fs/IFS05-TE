#ifndef TYPES_H
#define TYPES_H

enum OdoType { REGULAR, TRIP };

enum State { WAIT_SYNC, RUNNING };

#endif
